﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sagnay_Luis_Leccion2
{
    public class DDAAlgorithm
    {
        private Graphics mGraph;
        private Pen mPen;
        private int startX, startY, endX, endY;

        private void DrawPixel(int x, int y)
        {
            mGraph.DrawRectangle(mPen, x, y, 1, 1);
        }

        private void InitializeDrawingTools(PictureBox picCanvas)
        {
            mGraph = picCanvas.CreateGraphics();
            mPen = new Pen(Color.Blue, 1);
        }

        public void DrawLine(PictureBox picCanvas, int startX, int startY, int endX, int endY, Color color, int size)
        {
            mGraph = picCanvas.CreateGraphics();
            mPen = new Pen(color, size);

            int dx = endX - startX;
            int dy = endY - startY;
            float m = dx != 0 ? (float)dy / dx : float.PositiveInfinity;
            int steps = Math.Max(Math.Abs(dx), Math.Abs(dy));

            float xk = startX;
            float yk = startY;

            int centerX = picCanvas.Width / 2;
            int centerY = picCanvas.Height / 2;

            for (int i = 0; i <= steps; i++)
            {
                int xCanvas = (int)Math.Round(centerX + xk);
                int yCanvas = (int)Math.Round(centerY - yk);

                DrawPixel(xCanvas, yCanvas);

                if (Math.Abs(m) <= 1)
                {
                    xk += (dx >= 0) ? 1 : -1;
                    yk += (dx >= 0) ? m : -m;
                }
                else
                {
                    yk += (dy >= 0) ? 1 : -1;
                    xk += (dy >= 0) ? 1 / m : -1 / m;
                }
            }
        }

    }
}
